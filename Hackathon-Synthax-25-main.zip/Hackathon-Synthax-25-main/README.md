# Hackathon-Synthax-25
The Synthax Hackathon Github Repo for our team.

[Our Team Hackathon Document](https://docs.google.com/document/d/1EpGEQl6V3keKUzMRlnBHyqoPhK-lGpmv6hBE-m-bLxg/edit?usp=sharing) not viewable to all people.

## Inspiration
We found the idea when we realised **many people lose a lot of time** and are not productive.

## What it does
By giving people a more productive space without many distractions **it helps people be more productive.**

## How we built it
We used **Python, HTML, JS and CSS** to make an App and Website.

## Challenges we ran into
One of our teammates' parents mislead him which lead him to not be able to come for second day. We also couldn't completely finish it.

## Accomplishments that we're proud of
The **complete browser and notepad works great with many features and so does the carbon footprint**, and the website looks good.

## What we learned
Our teammates learned lot of coding, despite not knowing a lot. This was all of **our first hackathon** and the experience was great

## What's next for open tracker(web), praxis desk(app)
**Completing the AI and fixing other bugs which persisted over the complete hackathon** which we didn't have time to fix.

## Disclosure

https://www.youtube.com/watch?v=it1rTvBcfRg&list=PLP9IO4UYNF0VdAajP_5pYG-jG2JRrG72s tutorials for Soumil and Vashist

AI
Used Github Copilot for bug fixing, commits using AI given are written they used AI. 
Also the final commits all used a single AI review before commiting.



