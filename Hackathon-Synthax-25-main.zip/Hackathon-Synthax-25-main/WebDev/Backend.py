from flask import Flask, jsonify, request, abort, make_response
from flask_cors import CORS
import json
import time
from pathlib import Path
from datetime import datetime
import logging
import tempfile
import os

# --- Logging ---
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s %(levelname)s %(message)s')

# Data directory: make it relative to this file so different working dirs don't break things.
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / 'DATA'
DATA_DIR.mkdir(exist_ok=True)

FILES = {
    "projects": DATA_DIR / "projects.json",
    "sessions": DATA_DIR / "sessions.json",
    "schedules": DATA_DIR / "schedules.json",
    "alarms": DATA_DIR / "alarms.json",
}

# Ensure files exist and are valid JSON arrays
for name, f in FILES.items():
    if not f.exists():
        f.write_text("[]", encoding='utf-8')
    else:
        # ensure it's valid JSON array; if not, back it up and create a fresh []
        try:
            data = json.loads(f.read_text(encoding='utf-8'))
            if not isinstance(data, list):
                raise ValueError("store file not a list")
        except Exception as e:
            logging.warning("Invalid JSON in %s: %s -- backing up and resetting", f, e)
            backup = f.with_suffix('.bak')
            try:
                f.replace(backup)
                backup.write_text(json.dumps([], indent=2), encoding='utf-8')
            except Exception:
                # fallback: overwrite original
                f.write_text("[]", encoding='utf-8')

def read_store(name):
    p = FILES[name]
    try:
        with p.open('r', encoding='utf-8') as fh:
            return json.load(fh)
    except Exception as e:
        logging.exception("read_store failed for %s", p)
        # return empty list to keep UI usable
        return []

def write_store(name, data):
    p = FILES[name]
    # atomic write: write to temp file then replace
    try:
        dirpath = p.parent
        with tempfile.NamedTemporaryFile('w', delete=False, dir=str(dirpath), encoding='utf-8') as tf:
            json.dump(data, tf, ensure_ascii=False, indent=2)
            tempname = tf.name
        os.replace(tempname, str(p))
    except Exception:
        logging.exception("write_store failed for %s", p)
        raise

def gen_id():
    # millisecond timestamp id
    return int(time.time() * 1000)

app = Flask(__name__, static_folder='static', static_url_path='')
CORS(app)

@app.errorhandler(400)
@app.errorhandler(404)
@app.errorhandler(500)
def json_error(e):
    # return JSON for errors so frontend can show message
    code = getattr(e, 'code', 500)
    msg = getattr(e, 'description', str(e))
    logging.error("HTTP %s: %s", code, msg)
    return make_response(jsonify({'error': msg}), code)

@app.route('/', methods=['GET'])
def index():
    return app.send_static_file('index.html')

@app.route('/api/BackendConnect', methods=['GET'])
def backend_connect():
    return jsonify({"ok": True, "serverTime": datetime.utcnow().isoformat() + "Z"})

# --- Projects ---
@app.route('/api/projects', methods=['GET'])
def list_projects():
    return jsonify(read_store('projects'))

@app.route('/api/projects', methods=['POST'])
def create_project():
    payload = request.get_json(silent=True)
    if payload is None:
        abort(400, 'Invalid JSON payload')
    name = (payload.get('name') or '').strip()
    if not name:
        abort(400, 'name required')
    project = {
        "id": payload.get('id') or f"{name.lower().replace(' ', '_')}_{gen_id()}",
        "name": name,
        "totalTime": float(payload.get('totalTime') or 0.0)
    }
    try:
        data = read_store('projects')
        data.append(project)
        write_store('projects', data)
        logging.info("Created project %s", project['id'])
        return jsonify(project), 201
    except Exception as e:
        logging.exception("Failed to persist project")
        abort(500, 'Failed to save project (server error)')

@app.route('/api/projects/<project_id>', methods=['DELETE'])
def delete_project(project_id):
    try:
        data = read_store('projects')
        new = [p for p in data if str(p['id']) != str(project_id)]
        if len(new) == len(data):
            abort(404, 'project not found')
        write_store('projects', new)
        # also remove references in sessions and schedules
        sessions = [s for s in read_store('sessions') if str(s.get('projectId')) != str(project_id)]
        write_store('sessions', sessions)
        schedules = [s for s in read_store('schedules') if str(s.get('projectId')) != str(project_id)]
        write_store('schedules', schedules)
        logging.info("Deleted project %s", project_id)
        return '', 204
    except Exception:
        logging.exception("Failed to delete project")
        abort(500, 'Failed to delete project (server error)')

# --- Sessions ---
@app.route('/api/sessions', methods=['GET'])
def list_sessions():
    return jsonify(read_store('sessions'))

@app.route('/api/sessions', methods=['POST'])
def create_session():
    payload = request.get_json(silent=True)
    if payload is None:
        abort(400, 'Invalid JSON payload')
    required = ['projectId', 'task', 'duration', 'date']
    for r in required:
        if r not in payload:
            abort(400, f'{r} required')
    session = {
        "id": payload.get('id') or gen_id(),
        "projectId": payload['projectId'],
        "task": payload['task'],
        "duration": payload['duration'],  # seconds
        "date": payload['date']
    }
    try:
        data = read_store('sessions')
        data.append(session)
        write_store('sessions', data)
        # update project's totalTime
        projects = read_store('projects')
        for p in projects:
            if str(p['id']) == str(session['projectId']):
                p['totalTime'] = float(p.get('totalTime', 0) + session['duration'] / 3600.0)
        write_store('projects', projects)
        logging.info("Created session %s", session['id'])
        return jsonify(session), 201
    except Exception:
        logging.exception("Failed to save session")
        abort(500, 'Failed to save session (server error)')

# --- Schedules (calendar events) ---
@app.route('/api/schedules', methods=['GET'])
def list_schedules():
    return jsonify(read_store('schedules'))

@app.route('/api/schedules', methods=['POST'])
def create_schedule():
    payload = request.get_json(silent=True)
    if payload is None:
        abort(400, 'Invalid JSON payload')
    required = ['title', 'datetimeISO']
    for r in required:
        if r not in payload:
            abort(400, f'{r} required')
    schedule = {
        "id": payload.get('id') or gen_id(),
        "projectId": payload.get('projectId'),
        "title": payload['title'],
        "datetimeISO": payload['datetimeISO']
    }
    try:
        data = read_store('schedules')
        data.append(schedule)
        write_store('schedules', data)
        logging.info("Created schedule %s", schedule['id'])
        return jsonify(schedule), 201
    except Exception:
        logging.exception("Failed to save schedule")
        abort(500, 'Failed to save schedule (server error)')

@app.route('/api/schedules/<int:sid>', methods=['DELETE'])
def delete_schedule(sid):
    try:
        data = read_store('schedules')
        new = [s for s in data if int(s['id']) != int(sid)]
        if len(new) == len(data):
            abort(404, 'schedule not found')
        write_store('schedules', new)
        logging.info("Deleted schedule %s", sid)
        return '', 204
    except Exception:
        logging.exception("Failed to delete schedule")
        abort(500, 'Failed to delete schedule (server error)')

# --- Alarms ---
@app.route('/api/alarms', methods=['GET'])
def list_alarms():
    return jsonify(read_store('alarms'))

@app.route('/api/alarms', methods=['POST'])
def create_alarm():
    payload = request.get_json(silent=True)
    if payload is None:
        abort(400, 'Invalid JSON payload')
    required = ['title', 'datetimeISO']
    for r in required:
        if r not in payload:
            abort(400, f'{r} required')
    alarm = {
        "id": payload.get('id') or gen_id(),
        "title": payload['title'],
        "datetimeISO": payload['datetimeISO'],
        "triggered": bool(payload.get('triggered', False))
    }
    try:
        alarms = read_store('alarms')
        alarms.append(alarm)
        write_store('alarms', alarms)
        logging.info("Created alarm %s", alarm['id'])
        return jsonify(alarm), 201
    except Exception:
        logging.exception("Failed to save alarm")
        abort(500, 'Failed to save alarm (server error)')

@app.route('/api/alarms/<int:aid>', methods=['DELETE'])
def delete_alarm(aid):
    try:
        data = read_store('alarms')
        new = [a for a in data if int(a['id']) != int(aid)]
        if len(new) == len(data):
            abort(404, 'alarm not found')
        write_store('alarms', new)
        logging.info("Deleted alarm %s", aid)
        return '', 204
    except Exception:
        logging.exception("Failed to delete alarm")
        abort(500, 'Failed to delete alarm (server error)')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
