import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import webbrowser
import json
import os
import time
from datetime import datetime
import threading
import traceback
import shutil

# --- LLM / Transformers imports are optional until you try to load the model ---
# They are imported inside the loader so the app can still run when packages aren't installed.

# --- Global State & Configuration ---
DRAFT_FILE = "ZenDeskDraft.json"
editor_tab_control = None
reminder_job = None
root = None
main_frame = None

# LLM globals
llm_model = None
llm_tokenizer = None
llm_available = False
llm_device = "cpu"
# Default model; you can override with env var ZEN_DESK_LLM
LLM_NAME = os.environ.get("ZEN_DESK_LLM", "TinyLlama/TinyLlama-1.1B-python-v0.1")
LLM_LOAD_IN_8BIT = os.environ.get("ZEN_DESK_LLM_8BIT", "1") == "1"  # set 0 to disable 8-bit attempt
LLM_TRUST_REMOTE_CODE = True  # required for many community models

# --- Helper Functions ---

def clear_frame(frame):
    """Destroy all children of a frame and clear references to destroyed widgets."""
    global editor_tab_control
    for widget in frame.winfo_children():
        try:
            # Clear global reference if we destroy the Notebook
            if editor_tab_control is not None and widget == editor_tab_control:
                editor_tab_control = None
        except Exception:
            pass
        widget.destroy()

def on_closing():
    """Save state and close the app cleanly."""
    global reminder_job, root
    try:
        if reminder_job is not None and root is not None:
            root.after_cancel(reminder_job)
        save_current_tabs_to_draft()
    except Exception as e:
        print("Error while saving draft on close:", e)
    try:
        if root is not None:
            root.quit()
            root.destroy()
    except Exception:
        pass

def _find_text_widget(container):
    """Return the first Text widget found in container's widget tree."""
    for child in container.winfo_children():
        if isinstance(child, tk.Text):
            return child
        for g in child.winfo_children():
            if isinstance(g, tk.Text):
                return g
    return None

def _notebook_alive(nb):
    """Check if the Notebook widget is alive before trying to access it."""
    return nb is not None and getattr(nb, 'winfo_exists', lambda: False)()

def get_notepad_content():
    """Retrieves the content of the currently active Smart Notepad tab."""
    global editor_tab_control
    if not _notebook_alive(editor_tab_control) or not editor_tab_control.tabs():
        return ""
    current_tab_id = editor_tab_control.select()
    tab_frame = editor_tab_control.nametowidget(current_tab_id)
    text_box = _find_text_widget(tab_frame)
    if text_box:
        return text_box.get('1.0', 'end-1c')
    return ""

def append_to_notepad(text):
    """Appends text to the active Smart Notepad tab, creating one if none exists."""
    global editor_tab_control, main_frame
    if not _notebook_alive(editor_tab_control):
        load_smart_notepad(main_frame)
    if editor_tab_control.tabs():
        current_tab_id = editor_tab_control.select()
        tab_frame = editor_tab_control.nametowidget(current_tab_id)
        text_box = _find_text_widget(tab_frame)
        if text_box:
            text_box.insert('end', '\n\n' + text)
            text_box.see('end')
            tab_frame.file_path = None  # Force re-save draft
            _mark_unsaved(text_box, editor_tab_control, current_tab_id, tab_frame)
        else:
            messagebox.showwarning("Error", "Could not find text box in active tab.")
    else:
        messagebox.showwarning("Error", "No active notepad tabs.")


def _mark_unsaved(text_box, tab_control, tab_id, tab_frame, event=None):
    """Helper to mark a specific tab as unsaved and save draft."""
    try:
        current_text = tab_control.tab(tab_id, 'text')
        if not current_text.endswith('*'):
            tab_control.tab(tab_id, text=current_text + '*')
        save_current_tabs_to_draft()
    except Exception:
        pass

# --- Draft Persistence Functions ---

def save_current_tabs_to_draft():
    """Save open tabs (path + content) to disk."""
    global editor_tab_control
    try:
        if not _notebook_alive(editor_tab_control):
            return
        draft_data = []
        try:
            tab_ids = editor_tab_control.tabs()
        except tk.TclError:
            return
        for tab_id in tab_ids:
            try:
                tab_frame = editor_tab_control.nametowidget(tab_id)
            except Exception:
                continue
            text_box = _find_text_widget(tab_frame)
            if not text_box:
                continue
            content = text_box.get('1.0', 'end-1c')
            tab_text = editor_tab_control.tab(tab_id, 'text').replace('*', '')
            file_path = None if tab_text == 'Untitled' else getattr(tab_frame, 'file_path', None)
            draft_data.append({'content': content, 'path': file_path})
        with open(DRAFT_FILE, 'w', encoding='utf-8') as f:
            json.dump(draft_data, f, indent=4)
    except Exception as e:
        print('Error saving draft:', e)

def load_draft():
    """Load previously saved draft data."""
    if os.path.exists(DRAFT_FILE):
        try:
            with open(DRAFT_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print('Error loading draft:', e)
            return []
    return []

# --- Smart Notepad Utility Functions ---

def create_new_tab(tab_control, file_path=None, content=''):
    """Creates a new editable tab in the notebook."""
    tab = tk.Frame(tab_control, bg='#1e1e1e')
    v_scrollbar = tk.Scrollbar(tab, orient='vertical')
    h_scrollbar = tk.Scrollbar(tab, orient='horizontal')
    text_box = tk.Text(tab, wrap='none', font=('Consolas', 11),
                        bg='#1e1e1e', fg='#dddddd', insertbackground='white', undo=True,
                        yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
    v_scrollbar.config(command=text_box.yview)
    h_scrollbar.config(command=text_box.xview)
    v_scrollbar.pack(side='right', fill='y')
    h_scrollbar.pack(side='bottom', fill='x')
    text_box.pack(expand=True, fill='both', side='left')
    if content:
        text_box.insert('1.0', content)
    tab_control.add(tab, text=os.path.basename(file_path) if file_path else 'Untitled')
    tab_control.select(tab)
    tab.file_path = file_path
    tab_id = tab_control.tabs()[-1]
    def mark_unsaved_wrapper(event=None):
        _mark_unsaved(text_box, tab_control, tab_id, tab)
    text_box.bind('<KeyRelease>', mark_unsaved_wrapper)
    # Markdown highlighting (basic)
    text_box.tag_configure('bold', font=('Consolas', 11, 'bold'), foreground='#4EC9B0')
    text_box.tag_configure('heading', font=('Consolas', 14, 'bold'), foreground='#9CDCFE')
    def apply_markdown_highlight(event=None):
        text_box.tag_remove('bold', '1.0', 'end')
        text_box.tag_remove('heading', '1.0', 'end')
        content = text_box.get('1.0', 'end-1c')
        lines = content.split('\n')
        for i, line in enumerate(lines):
            line_num = i + 1
            if line.startswith('# '):
                text_box.tag_add('heading', f'{line_num}.0', f'{line_num}.{len(line)}')
            start_index = 0
            while True:
                start = line.find('**', start_index)
                if start == -1: break
                end = line.find('**', start + 2)
                if end == -1: break
                text_box.tag_add('bold', f'{line_num}.{start}', f'{line_num}.{end + 2}')
                start_index = end + 2
    text_box.bind('<KeyRelease>', apply_markdown_highlight)
    if content:
        apply_markdown_highlight()

def open_file(tab_control):
    """Opens a file and creates a new tab for it."""
    file_path = filedialog.askopenfilename(title='Open File')
    if file_path:
        try:
            for tid in tab_control.tabs():
                t = tab_control.nametowidget(tid)
                if getattr(t, 'file_path', None) == file_path:
                    messagebox.showinfo('Already Open', 'This file is already open in a tab.')
                    tab_control.select(tid)
                    return
        except Exception:
            pass
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            create_new_tab(tab_control, file_path, content)
            save_current_tabs_to_draft()
        except Exception as e:
            messagebox.showerror('Error', f'Could not read file: {e}')

def save_file(tab_control):
    """Saves the content of the currently selected tab."""
    try:
        current_tab_id = tab_control.select()
        tab_frame = tab_control.nametowidget(current_tab_id)
        text_box = _find_text_widget(tab_frame)
        if not text_box:
            return
        content = text_box.get('1.0', 'end-1c')
        file_path = getattr(tab_frame, 'file_path', None)
        if not file_path:
            file_path = filedialog.asksaveasfilename(title='Save File As', defaultextension='.*')
            if not file_path:
                return
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        tab_frame.file_path = file_path
        tab_control.tab(current_tab_id, text=os.path.basename(file_path))
        save_current_tabs_to_draft()
    except Exception as e:
        messagebox.showerror('Error', f'Could not save file: {e}')

# --- Model Loader & AI Handler ---

def _set_llm_globals(model, tokenizer, device):
    global llm_model, llm_tokenizer, llm_available, llm_device
    llm_model = model
    llm_tokenizer = tokenizer
    llm_available = model is not None and tokenizer is not None
    llm_device = device

def load_tinyllama_model():
    """
    Robust loader for TinyLlama-like HF models.
    - Tries 8-bit load with bitsandbytes (if available + CUDA).
    - Tries float16 GPU load (if CUDA available).
    - Falls back to CPU float32.
    - If CPU fallback fails due to PyTorch 2.6 weights_only pickling constraints,
      attempts a temporary monkeypatch of torch.load(weights_only=False) for the HF call.
    Returns (model, tokenizer, device) or raises a helpful RuntimeError.
    """
    try:
        from transformers import AutoModelForCausalLM, AutoTokenizer
        import torch
    except Exception as imp_e:
        raise RuntimeError(
            "Transformers or torch not installed. Install with: pip install --upgrade transformers torch accelerate safetensors\n"
            f"Detailed error: {imp_e}"
        )

    model_name = LLM_NAME

    # Load tokenizer (fast preferred)
    try:
        tokenizer = AutoTokenizer.from_pretrained(model_name, use_fast=True)
    except Exception:
        tokenizer = AutoTokenizer.from_pretrained(model_name)

    base_kwargs = {
        "trust_remote_code": LLM_TRUST_REMOTE_CODE,
        "low_cpu_mem_usage": True,
    }

    # Try GPU + bitsandbytes 8-bit if available and requested
    try:
        if torch.cuda.is_available():
            if LLM_LOAD_IN_8BIT:
                try:
                    model = AutoModelForCausalLM.from_pretrained(
                        model_name,
                        load_in_8bit=True,
                        device_map="auto",
                        torch_dtype=torch.float16,
                        **base_kwargs
                    )
                    return model, tokenizer, "cuda"
                except Exception:
                    # continue to try full fp16 GPU load
                    pass
            model = AutoModelForCausalLM.from_pretrained(
                model_name,
                device_map="auto",
                torch_dtype=torch.float16,
                **base_kwargs
            )
            return model, tokenizer, "cuda"
        else:
            # CPU fallback (float32)
            model = AutoModelForCausalLM.from_pretrained(
                model_name,
                device_map={"": "cpu"},
                torch_dtype=torch.float32,
                **base_kwargs
            )
            return model, tokenizer, "cpu"

    except Exception as primary_e:
        # If primary error is a weights/unpickling problem, attempt a targeted monkeypatch
        primary_msg = str(primary_e).lower()
        tried_monkeypatch = False

        # Helper to try monkeypatching torch.load to force weights_only=False (only for torch >=2.6)
        try:
            import torch as _torch
            if ("weights_only" in primary_msg) or ("unpicklingerror" in primary_msg) or ("unable to load weights" in primary_msg):
                tried_monkeypatch = True
                original_torch_load = _torch.load

                def _patched_torch_load(*args, **kwargs):
                    if 'weights_only' not in kwargs:
                        kwargs = dict(kwargs, weights_only=False)
                    return original_torch_load(*args, **kwargs)

                try:
                    _torch.load = _patched_torch_load
                    model = AutoModelForCausalLM.from_pretrained(
                        model_name,
                        device_map={"": "cpu"},
                        torch_dtype=torch.float32,
                        trust_remote_code=LLM_TRUST_REMOTE_CODE,
                        low_cpu_mem_usage=True
                    )
                    return model, tokenizer, "cpu"
                finally:
                    try:
                        _torch.load = original_torch_load
                    except Exception:
                        pass
        except Exception:
            tried_monkeypatch = tried_monkeypatch or False

        # One more fallback try with minimal kwargs
        try:
            model = AutoModelForCausalLM.from_pretrained(model_name, device_map={"": "cpu"})
            return model, tokenizer, "cpu"
        except Exception as fallback_e:
            extra_note = ""
            if tried_monkeypatch:
                extra_note = (
                    "\nNote: An automatic torch.load(weights_only=False) attempt was performed and failed.\n"
                    "If that failed, either the checkpoint is incompatible or further environment changes are needed."
                )
            raise RuntimeError(
                f"Failed to load model '{model_name}'.\n"
                f"Primary attempt error: {primary_e}\n"
                f"Fallback attempt error: {fallback_e}\n"
                f"{extra_note}\n\n"
                "Non-downgrade fixes to try (recommended order):\n"
                "1) Install safetensors & force a clean re-download of the model so HF can use a .safetensors artifact (safe):\n"
                "   pip install --upgrade transformers accelerate safetensors\n"
                "   # Then delete the cached model folder and retry (Windows example):\n"
                "   rd /s /q %USERPROFILE%\\.cache\\huggingface\\hub\\models--" + model_name.replace("/", "--") + "\n\n"
                "2) If safetensors isn't available for that model, the code attempted a temporary monkeypatch to allow the older pickle-based weights to load.\n"
                "   That can succeed for trusted checkpoints. If not, try a different model that ships safetensors (or use an official HF model as a test):\n"
                "   set ZEN_DESK_LLM=google/flan-t5-small\n\n"
                "3) If you want me to integrate an automatic 'delete cache & retry' button and a 'use fallback model' option directly into the app UI, I can patch the file for you.\n"
            )

def initialize_llm_in_background(status_callback=None):
    """
    Starts loading the LLM in a background thread and calls status_callback(status_str) on updates.
    """
    def _worker():
        try:
            if status_callback:
                status_callback("Starting model load...")
            model, tokenizer, device = load_tinyllama_model()
            _set_llm_globals(model, tokenizer, device)
            try:
                model.eval()
            except Exception:
                pass
            if status_callback:
                status_callback(f"Model loaded on {device}. Ready.")
        except Exception as e:
            tb = traceback.format_exc()
            if status_callback:
                status_callback(f"Model load failed: {e}\n\n{tb}")
            # keep llm_available False
    t = threading.Thread(target=_worker, daemon=True)
    t.start()

def _generate_with_llm(prompt, max_new_tokens=128):
    """
    Uses llm_model/llm_tokenizer to generate a response. Returns plain text.
    """
    global llm_model, llm_tokenizer, llm_device
    if not llm_available or llm_model is None or llm_tokenizer is None:
        raise RuntimeError("LLM not loaded")
    try:
        import torch
        inputs = llm_tokenizer(prompt, return_tensors="pt", truncation=True)
        input_ids = inputs["input_ids"]
        attention_mask = inputs.get("attention_mask", None)
        if llm_device == "cuda":
            input_ids = input_ids.cuda()
            if attention_mask is not None:
                attention_mask = attention_mask.cuda()
            model = llm_model.to("cuda")
        else:
            model = llm_model.to("cpu")
        with torch.no_grad():
            gen_kwargs = dict(max_new_tokens=max_new_tokens, do_sample=True, top_p=0.95, temperature=0.7)
            if getattr(llm_tokenizer, "pad_token_id", None) is None:
                gen_kwargs["pad_token_id"] = getattr(llm_tokenizer, "eos_token_id", 0)
            output = model.generate(input_ids=input_ids, attention_mask=attention_mask, **gen_kwargs)
        decoded = llm_tokenizer.decode(output[0], skip_special_tokens=True)
        if decoded.startswith(prompt):
            return decoded[len(prompt):].strip()
        return decoded.strip()
    except Exception as e:
        raise RuntimeError(f"LLM generation error: {e}")

def _handle_ai_query(query, context):
    """Handler to answer AI queries. Uses local model if available, otherwise built-in fallback."""
    global llm_available
    lower_query = query.lower()
    if "study" in lower_query and "question" in lower_query:
        first_lines = context.strip().splitlines()
        snippet = first_lines[0] if first_lines else "your notes"
        return f"1. What is the main idea of: '{snippet[:80]}'?\n2. List 3 key terms.\n3. How does this connect to prior knowledge?"
    if llm_available:
        try:
            prompt = f"Context:\n{context}\n\nUser Query:\n{query}\n\nAnswer concisely:"
            answer = _generate_with_llm(prompt, max_new_tokens=256)
            if not answer:
                return "ZenDesk AI: Model responded with empty output."
            return answer
        except Exception as e:
            return f"ZenDesk AI (model error): {e}"
    return "ZenDesk AI (local mode): Model not loaded. Click 'Load Model' to initialize an LLM, or use 'Gen Study Questions' for a quick built-in mode."

# --- Module Panels ---

def delete_hf_cache_for_model(model_name):
    """Delete Hugging Face cache folder for the specified model (best-effort)."""
    cache_root = os.path.join(os.path.expanduser("~"), ".cache", "huggingface", "hub")
    folder_name = f"models--{model_name.replace('/', '--')}"
    target = os.path.join(cache_root, folder_name)
    if os.path.exists(target):
        try:
            shutil.rmtree(target)
            return True, target
        except Exception as e:
            return False, str(e)
    return False, f"Not found: {target}"

def set_fallback_model_and_load(new_model, status_callback=None):
    """Set a fallback LLM model and start loading it."""
    global LLM_NAME
    os.environ["ZEN_DESK_LLM"] = new_model
    LLM_NAME = new_model
    if status_callback:
        status_callback(f"Switched to fallback model: {new_model}. Loading now...")
    initialize_llm_in_background(status_callback=status_callback)

def load_ai_assistant(frame):
    """Loads the AI Assistant Panel with chat UI and context integration. Also can load LLM in background."""
    save_current_tabs_to_draft()
    clear_frame(frame)
    frame.configure(bg='#121212')

    tk.Label(frame, text='🧠 AI Assistant Panel', font=('Helvetica', 18, 'bold'), fg='#4EC9B0', bg='#121212').pack(pady=10)
    output_frame = tk.Frame(frame, bg='#1e1e1e')
    output_frame.pack(expand=True, fill='both', padx=20, pady=5)

    output_box = tk.Text(output_frame, wrap='word', font=('Consolas', 11), bg='#1e1e1e', fg='#dddddd', insertbackground='white', state='disabled')
    output_box.pack(side='left', expand=True, fill='both')
    scrollbar = tk.Scrollbar(output_frame, command=output_box.yview)
    scrollbar.pack(side='right', fill='y')
    output_box.configure(yscrollcommand=scrollbar.set)

    def append_output(text, tag=None):
        output_box.config(state='normal')
        if tag:
            output_box.insert('end', text + "\n", tag)
        else:
            output_box.insert('end', text + "\n")
        output_box.config(state='disabled')
        output_box.see('end')

    append_output("Welcome to ZenDesk AI Assistant. Ask me anything!\nTry typing 'research latest news' or 'explain this concept'.\n")

    input_frame = tk.Frame(frame, bg='#121212')
    input_frame.pack(fill='x', padx=20, pady=10)

    command_entry = tk.Entry(input_frame, font=('Consolas', 11), bg='#2e2e2e', fg='white', insertbackground='white')
    command_entry.pack(side='left', expand=True, fill='x', padx=(0, 10))
    send_button = tk.Button(input_frame, text='Ask AI', bg='#569CD6', fg='white', relief='flat', padx=10)
    send_button.pack(side='left')

    control_frame = tk.Frame(frame, bg='#121212')
    control_frame.pack(fill='x', padx=20, pady=(0,10))

    status_var = tk.StringVar(value="LLM: Not loaded")
    status_label = tk.Label(control_frame, textvariable=status_var, font=('Helvetica', 10), fg='#FCD34D', bg='#121212')
    status_label.pack(side='left')

    def status_callback(text):
        def _update():
            status_var.set(text)
            append_output(text)
        if root:
            root.after(0, _update)
        else:
            _update()

    def load_model_now():
        status_var.set("LLM: Loading in background...")
        append_output("Loading model in background. This may take a few minutes (and may download a few GB depending on model).")
        initialize_llm_in_background(status_callback=status_callback)

    tk.Button(control_frame, text='Load Model', command=load_model_now, bg='#6C8EBF', fg='white', relief='flat', padx=10).pack(side='right', padx=4)

    # Delete cache & retry button
    def delete_cache_then_retry():
        nonlocal status_var
        model_name = LLM_NAME
        if messagebox.askyesno("Delete HF Cache", f"Delete cached files for '{model_name}' and reload? This will force re-download. Continue?"):
            success, info = delete_hf_cache_for_model(model_name)
            if success:
                status_callback(f"Deleted cache: {info}. Restarting model load...")
                initialize_llm_in_background(status_callback=status_callback)
            else:
                messagebox.showerror("Delete Failed", f"Could not delete cache: {info}")

    tk.Button(control_frame, text='Delete Cache & Retry', command=delete_cache_then_retry, bg='#E67E22', fg='white', relief='flat', padx=10).pack(side='right', padx=4)

    # Use fallback model button
    def use_safe_fallback():
        if messagebox.askyesno("Use Fallback Model", "Switch to a known-safe, smaller model (google/flan-t5-small) to test LLM loading?"):
            set_fallback_model_and_load("google/flan-t5-small", status_callback=status_callback)

    tk.Button(control_frame, text='Use Fallback Model', command=use_safe_fallback, bg='#4CAF50', fg='white', relief='flat', padx=10).pack(side='right', padx=4)

    def run_query(event=None):
        cmd = command_entry.get().strip()
        if not cmd:
            return
        notepad_content = get_notepad_content()
        append_output(f"[You: {cmd}]")
        append_output(f'[{datetime.now().strftime("%H:%M:%S")}] Querying AI...', tag='loading')
        output_box.tag_configure('loading', foreground='#FCD34D')
        command_entry.delete(0, 'end')
        def process_response():
            response = _handle_ai_query(cmd, notepad_content)
            append_output(f'\n{response}\n')
        if root:
            root.after(100, process_response)
        else:
            process_response()

    command_entry.bind('<Return>', run_query)
    send_button.config(command=run_query)
    command_entry.focus_set()

def load_smart_notepad(frame):
    """Loads the Smart Notepad, retaining the existing editor logic with enhancements."""
    global editor_tab_control, main_frame
    main_frame = frame
    tabs_to_load = load_draft()
    clear_frame(frame)
    frame.configure(bg='#1e1e1e')
    tk.Label(frame, text='📝 Smart Notepad', font=('Helvetica', 18, 'bold'), fg='#9CDCFE', bg='#1e1e1e').pack(pady=10)
    button_frame = tk.Frame(frame, bg='#1e1e1e')
    button_frame.pack(pady=5)
    button_opts = {'font': ('Helvetica', 10, 'bold'), 'bg': '#2d2d2d', 'fg': 'white', 'relief': 'flat', 'padx': 10, 'pady': 5}
    editor_tab_control = ttk.Notebook(frame)
    editor_tab_control.pack(expand=True, fill='both', padx=20, pady=10)
    if tabs_to_load:
        for item in tabs_to_load:
            create_new_tab(editor_tab_control, item.get('path'), item.get('content'))
    if not editor_tab_control.tabs():
        create_new_tab(editor_tab_control, content='# ZenDesk Notes\n**Welcome!** This is your smart, auto-saving notepad.')
    tk.Button(button_frame, text='New Tab', command=lambda: create_new_tab(editor_tab_control), **button_opts).pack(side='left', padx=5)
    tk.Button(button_frame, text='Open File', command=lambda: open_file(editor_tab_control), **button_opts).pack(side='left', padx=5)
    tk.Button(button_frame, text='Save', command=lambda: save_file(editor_tab_control), **button_opts).pack(side='left', padx=5)
    def generate_study_questions():
        content = get_notepad_content()
        if not content:
            messagebox.showwarning("AI Warning", "Notepad is empty. Write some notes first!")
            return
        response = _handle_ai_query("Generate study questions", content)
        messagebox.showinfo("AI Response", response)
    tk.Button(button_frame, text='🧠 Gen Study Questions', command=generate_study_questions, bg='#8BC34A', fg='white', relief='flat', padx=10, pady=5).pack(side='left', padx=15)

def load_integrated_browser(frame):
    save_current_tabs_to_draft()
    clear_frame(frame)
    frame.configure(bg='#34495e')
    tk.Label(frame, text='🌐 Integrated Browser', font=('Helvetica', 18, 'bold'), fg='#ecf0f1', bg='#34495e').pack(pady=10)
    tk.Label(frame, text='URL:', font=('Helvetica', 12), fg='#ecf0f1', bg='#34495e').pack(pady=(15, 0))
    url_var = tk.StringVar(value='https://www.google.com')
    url_entry = tk.Entry(frame, textvariable=url_var, font=('Helvetica', 12), bg='#496078', fg='white', insertbackground='white', justify='center')
    url_entry.pack(fill='x', padx=40, pady=5)
    def open_url(event=None):
        url = url_var.get().strip()
        if not url.startswith('http'):
            url = 'http://' + url
        try:
            webbrowser.open_new_tab(url)
            status_label.config(text=f'Opened in System Browser: {url}', fg='#2ecc71')
        except Exception as e:
            status_label.config(text=f'Error opening browser: {e}', fg='#e74c3c')
    def capture_citation():
        url = url_var.get().strip()
        if not url:
            messagebox.showwarning("Warning", "Please enter a URL first.")
            return
        title = url.split('/')[-1].replace('-', ' ').title() if url.split('/')[-1] else 'Untitled Source'
        citation = f"--- Citation Captured ({datetime.now().strftime('%Y-%m-%d')}) ---\nSource: {title}\nURL: {url}\n"
        append_to_notepad(citation)
        status_label.config(text=f'Citation Captured to Notepad!', fg='#F1C40F')
    button_frame = tk.Frame(frame, bg='#34495e')
    button_frame.pack(pady=10)
    tk.Button(button_frame, text='Go / Open URL', command=open_url, font=('Helvetica', 12, 'bold'), bg='#1abc9c', fg='white', relief='flat', padx=10, pady=5).pack(side='left', padx=10)
    tk.Button(button_frame, text='📌 Capture Citation to Notes', command=capture_citation, font=('Helvetica', 12), bg='#E67E22', fg='white', relief='flat', padx=10, pady=5).pack(side='left', padx=10)
    url_entry.bind('<Return>', open_url)
    status_label = tk.Label(frame, text="Ready.", font=('Helvetica', 10), fg='#bdc3c7', bg='#34495e')
    status_label.pack(pady=10)

def load_health_monitoring(frame):
    global reminder_job, root
    save_current_tabs_to_draft()
    clear_frame(frame)
    frame.configure(bg='#2C3E50')
    tk.Label(frame, text='💚 Health Monitoring', font=('Helvetica', 18, 'bold'), fg='#2ECC71', bg='#2C3E50').pack(pady=10)
    status_var = tk.StringVar(value="Status: Inactive")
    timer_var = tk.StringVar(value="Next Reminder: N/A")
    status_label = tk.Label(frame, textvariable=status_var, font=('Helvetica', 14), fg='white', bg='#2C3E50')
    status_label.pack(pady=5)
    timer_label = tk.Label(frame, textvariable=timer_var, font=('Helvetica', 12), fg='#BDC3C7', bg='#2C3E50')
    timer_label.pack(pady=5)
    def check_reminders():
        global reminder_job
        DEMO_INTERVAL = 60000
        current_time_s = time.time()
        if int(current_time_s) % 60 == 0:
            messagebox.showinfo("ZenDesk Health: 20-20-20 Rule", "Take an eye break! Look at something 20 feet away for 20 seconds.")
        elif int(current_time_s) % 120 == 0:
            messagebox.showinfo("ZenDesk Health: Posture Check", "Check your posture! Sit up straight and adjust your screen height.")
        timer_var.set(f"Next Timer Check: {datetime.now().strftime('%H:%M:%S')}")
        reminder_job = root.after(DEMO_INTERVAL, check_reminders)
    def start_monitoring():
        global reminder_job
        if reminder_job is None:
            status_var.set("Status: ACTIVE (Checking every 60s)")
            reminder_job = root.after(1000, check_reminders)
            start_button.config(text="Stop Monitoring", command=stop_monitoring, bg='#E74C3C')
            messagebox.showinfo("Health Monitoring", "Health reminders started.")
    def stop_monitoring():
        global reminder_job
        if reminder_job is not None:
            root.after_cancel(reminder_job)
            reminder_job = None
            status_var.set("Status: Inactive")
            timer_var.set("Next Reminder: N/A")
            start_button.config(text="Start Monitoring", command=start_monitoring, bg='#2ECC71')
            messagebox.showinfo("Health Monitoring", "Health reminders stopped.")
    start_button = tk.Button(frame, text='Start Monitoring', command=start_monitoring, font=('Helvetica', 12, 'bold'), bg='#2ECC71', fg='white', relief='flat', padx=10, pady=5)
    start_button.pack(pady=20)
    tk.Label(frame, text="Reminders will pop up based on 20-20-20 rule and timed posture checks.", fg='#BDC3C7', bg='#2C3E50').pack(pady=10)

def load_eco_hub(frame):
    save_current_tabs_to_draft()
    clear_frame(frame)
    frame.configure(bg='#1B5E20')
    tk.Label(frame, text='🌳 Eco Hub', font=('Helvetica', 18, 'bold'), fg='#C8E6C9', bg='#1B5E20').pack(pady=10)
    pane = ttk.PanedWindow(frame, orient=tk.HORIZONTAL)
    pane.pack(fill='both', expand=True, padx=20, pady=10)
    chat_frame = tk.Frame(pane, bg='#388E3C')
    pane.add(chat_frame, weight=1)
    tk.Label(chat_frame, text='EcoBot (Sustainability Chat)', font=('Helvetica', 14, 'bold'), fg='white', bg='#388E3C').pack(pady=5)
    chat_output_box = tk.Text(chat_frame, wrap='word', font=('Consolas', 10), bg='#2E7D32', fg='white', insertbackground='white', state='disabled')
    chat_output_box.pack(expand=True, fill='both', padx=10, pady=(0, 5))
    chat_input_entry = tk.Entry(chat_frame, font=('Consolas', 10), bg='#4CAF50', fg='white', insertbackground='white')
    chat_input_entry.pack(fill='x', padx=10, pady=(0, 10))
    def run_ecobot(event=None):
        query = chat_input_entry.get().strip().lower()
        if not query:
            return
        chat_output_box.config(state='normal')
        chat_output_box.insert('end', f'\n[You: {query.capitalize()}]\n')
        response = "EcoBot: I'm designed to provide tips on eco-living. Try asking about 'e-waste', 'water conservation', or 'carbon footprint'."
        if 'waste' in query or 'reduce' in query:
            response = "EcoBot: To reduce waste, focus on the 5 Rs: Refuse, Reduce, Reuse, Repurpose, and Recycle."
        elif 'water' in query:
            response = "EcoBot: For water conservation, take shorter showers, fix leaks, and only run full loads."
        elif 'footprint' in query or 'carbon' in query:
            response = "EcoBot: Reduce carbon by using public transport, eating less meat, and energy-efficient appliances."
        chat_output_box.insert('end', response + '\n')
        chat_output_box.config(state='disabled')
        chat_output_box.see('end')
        chat_input_entry.delete(0, 'end')
    chat_input_entry.bind('<Return>', run_ecobot)
    chat_output_box.config(state='normal')
    chat_output_box.insert('end', "Welcome to EcoBot. Ask for tips on sustainable living!\n")
    chat_output_box.config(state='disabled')
    calc_frame = tk.Frame(pane, bg='#4CAF50')
    pane.add(calc_frame, weight=1)
    tk.Label(calc_frame, text='Carbon Footprint Calculator', font=('Helvetica', 14, 'bold'), fg='white', bg='#4CAF50').pack(pady=5)
    flight_var = tk.DoubleVar(value=0)
    car_var = tk.DoubleVar(value=0)
    tk.Label(calc_frame, text='Avg. Monthly Flight Hours:', fg='white', bg='#4CAF50').pack(pady=5)
    ttk.Entry(calc_frame, textvariable=flight_var, width=10, justify='center').pack()
    tk.Label(calc_frame, text='Avg. Weekly Car Miles:', fg='white', bg='#4CAF50').pack(pady=5)
    ttk.Entry(calc_frame, textvariable=car_var, width=10, justify='center').pack()
    result_var = tk.StringVar(value='Your Footprint: ?')
    def calculate_footprint():
        try:
            flights = flight_var.get()
            car = car_var.get()
            footprint = (flights * 0.2) + (car * 0.0004)
            result_var.set(f'Your Est. Annual Footprint: {footprint:.2f} tons CO2e')
        except:
            result_var.set('Error: Invalid input')
    tk.Button(calc_frame, text='Calculate', command=calculate_footprint, bg='#A5D6A7', fg='#1B5E20', relief='flat', padx=10, pady=5).pack(pady=15)
    tk.Label(calc_frame, textvariable=result_var, font=('Helvetica', 12, 'bold'), fg='#1B5E20', bg='#4CAF50').pack(pady=5)
    tk.Label(calc_frame, text='\nGreen Challenge Tracker', font=('Helvetica', 14, 'bold'), fg='white', bg='#4CAF50').pack(pady=10)
    tk.Label(calc_frame, text='- Go paperless for a week\n- Plant a digital tree\n- Use a reusable coffee cup daily', justify='left', fg='white', bg='#4CAF50').pack(pady=5)

# --- Main UI Setup ---

def initialize_zen_desk():
    """Initializes the main Tkinter window and UI components."""
    global root, main_frame
    root = tk.Tk()
    root.title('ZenDesk Productivity Suite')
    root.geometry('1000x600')
    root.configure(bg='#1e1e1e')
    root.protocol('WM_DELETE_WINDOW', on_closing)

    style = ttk.Style()
    try:
        style.theme_create('zendesk_dark', parent='alt', settings={
            'TNotebook': {'configure': {'tabmargins': [2, 5, 2, 0], 'background': '#1e1e1e', 'bordercolor': '#2d2d2d'}},
            'TNotebook.Tab': {
                'configure': {'padding': [15, 5], 'background': '#2d2d2d', 'foreground': 'white'},
                'map': {'background': [('selected', '#1e1e1e'), ('active', '#3c3c3c')], 'foreground': [('selected', '#4EC9B0')]}
            }
        })
        style.theme_use('zendesk_dark')
    except Exception:
        pass

    sidebar = tk.Frame(root, width=200, bg='#2b2b2b')
    sidebar.pack(side='left', fill='y')
    tk.Label(sidebar, text='ZEN DESK', font=('Helvetica', 16, 'bold'), fg='#4EC9B0', bg='#2b2b2b').pack(pady=20)
    tk.Label(sidebar, text='Productivity Modules', font=('Helvetica', 10), fg='#888888', bg='#2b2b2b').pack()
    main_frame = tk.Frame(root, bg='#1e1e1e')
    main_frame.pack(side='right', expand=True, fill='both')
    button_opts = {'font': ('Helvetica', 12), 'bg': '#3c3c3c', 'fg': 'white', 'relief': 'flat', 'activebackground': '#555555'}
    tk.Button(sidebar, text='🧠 AI Assistant', command=lambda: load_ai_assistant(main_frame), **button_opts).pack(pady=5, fill='x', padx=10)
    tk.Button(sidebar, text='📝 Smart Notepad', command=lambda: load_smart_notepad(main_frame), **button_opts).pack(pady=5, fill='x', padx=10)
    tk.Button(sidebar, text='🌐 Integrated Browser', command=lambda: load_integrated_browser(main_frame), **button_opts).pack(pady=5, fill='x', padx=10)
    tk.Button(sidebar, text='💚 Health Monitoring', command=lambda: load_health_monitoring(main_frame), **button_opts).pack(pady=5, fill='x', padx=10)
    tk.Button(sidebar, text='🌳 Eco Hub', command=lambda: load_eco_hub(main_frame), **button_opts).pack(pady=5, fill='x', padx=10)
    load_smart_notepad(main_frame)
    root.mainloop()

# Ensure the app starts cleanly
if __name__ == '__main__':
    initialize_zen_desk()