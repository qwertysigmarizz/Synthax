#!/usr/bin/env python3
"""
Pyqt_browser - lightweight PyQt browser with optional ddgs integration.

This script will:
- Try to use PyQtWebEngine (QWebEngineView). If it's not installed it falls back
  to opening URLs in the system browser and shows a helpful message.
- Provide a simple UI to open URLs, create tabs, add bookmarks and view history.
- If PyQtWebEngine is available, it supports in-app DuckDuckGo searches using the
  ddgs package (if ddgs is installed). If ddgs is missing, the search falls back
  to opening DuckDuckGo web search in the system browser.

To enable full functionality (in-app browsing + programmatic DDG results) install:
    pip install PyQtWebEngine ddgs

If you only want basic behavior (open links in your system browser), you don't
need PyQtWebEngine.
"""

import sys
import os
import json
import traceback
import urllib.parse
import webbrowser
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QPushButton, QLineEdit,
    QTabWidget, QToolBar, QAction, QMessageBox, QLabel
)
from PyQt5.QtCore import QUrl, QDateTime, QThread, pyqtSignal

# Try to import web engine; if not available we'll fallback.
USE_WEBENGINE = True
try:
    from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEngineProfile, QWebEnginePage
except Exception:
    USE_WEBENGINE = False

# Data paths
DATA_DIR = os.path.join(os.path.expanduser("~"), ".pyqt_browser")
BOOKMARKS_FILE = os.path.join(DATA_DIR, "bookmarks.json")
HISTORY_FILE = os.path.join(DATA_DIR, "history.json")
os.makedirs(DATA_DIR, exist_ok=True)


def load_json(path):
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return []
    return []


def save_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


class SearchWorker(QThread):
    html_ready = pyqtSignal(str, str)
    error = pyqtSignal(str)

    def __init__(self, query: str, max_results: int = 10, parent=None):
        super().__init__(parent)
        self.query = query
        self.max_results = max_results

    def run(self):
        try:
            from ddgs import DDGS
            results = []
            with DDGS() as ddgs:
                for r in ddgs.text(self.query, max_results=self.max_results):
                    results.append(r)

            if not results:
                html = f"<html><body><h2>No results for: {self.query}</h2></body></html>"
                self.html_ready.emit(html, f"Search: {self.query}")
                return

            parts = ["<html><head><meta charset='utf-8'><style>body{font-family:Arial;margin:20px} a{color:#1a0dab}</style></head><body>"]
            parts.append(f"<h1>Search results for: {self.query}</h1>")
            for i, r in enumerate(results, 1):
                title = r.get("title", "No title")
                href = r.get("href", "#")
                snippet = r.get("body", "")
                parts.append(f"<div><h3>{i}. <a href='{href}'>{title}</a></h3><p>{snippet}</p></div>")
            parts.append("</body></html>")
            html = "\n".join(parts)
            self.html_ready.emit(html, f"Search: {self.query}")
        except Exception as e:
            tb = traceback.format_exc()
            self.error.emit(str(e) + "\n\n" + tb)


if USE_WEBENGINE:
    class BrowserTab(QWebEngineView):
        def __init__(self, private=False):
            if private:
                profile = QWebEngineProfile()
                try:
                    profile.setPersistentCookiesPolicy(QWebEngineProfile.NoPersistentCookies)
                except Exception:
                    pass
                page = QWebEnginePage(profile, None)
                super().__init__(page)
            else:
                super().__init__()
            self.loadFinished.connect(self._on_load_finished)

        def _on_load_finished(self, ok):
            if not ok:
                return
            try:
                url = self.url().toString()
                title = self.title() or url
                timestamp = QDateTime.currentDateTime().toString()
                history = load_json(HISTORY_FILE)
                if not history or history[-1].get("url") != url:
                    history.append({"url": url, "title": title, "timestamp": timestamp})
                    if len(history) > 2000:
                        history = history[-2000:]
                    save_json(HISTORY_FILE, history)
            except Exception:
                pass
else:
    class BrowserTab(QWidget):
        """
        Fallback tab for environments without PyQtWebEngine.
        It displays a simple notice; navigation opens the system browser.
        """
        def __init__(self, private=False):
            super().__init__()
            layout = QVBoxLayout(self)
            notice = QLabel(
                "<b>PyQtWebEngine is not installed.</b><br>"
                "This tab cannot render web pages. URLs and searches will open in your system browser."
            )
            notice.setWordWrap(True)
            layout.addWidget(notice)


class PyqtBrowser(QMainWindow):
    DEFAULT_HOME = "https://www.example.com"

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Pyqt_browser")
        self.resize(1100, 700)

        self.tabs = QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.currentChanged.connect(self._on_tab_changed)
        self.setCentralWidget(self.tabs)

        self.toolbar = QToolBar()
        self.addToolBar(self.toolbar)

        self.url_input = QLineEdit()
        self.url_input.setPlaceholderText("Enter URL or search...")
        self.url_input.returnPressed.connect(self.go_to_url)

        go_btn = QPushButton("Go")
        go_btn.clicked.connect(self.go_to_url)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search DuckDuckGo (ddgs)")
        self.search_input.returnPressed.connect(self.search_ddgs)

        search_btn = QPushButton("Search")
        search_btn.clicked.connect(self.search_ddgs)

        self.toolbar.addWidget(self.url_input)
        self.toolbar.addWidget(go_btn)
        self.toolbar.addSeparator()
        self.toolbar.addWidget(self.search_input)
        self.toolbar.addWidget(search_btn)
        self.toolbar.addSeparator()

        self.toolbar.addAction(QAction("New Tab", self, triggered=self.new_tab))
        self.toolbar.addAction(QAction("Private Tab", self, triggered=self.private_tab))
        self.toolbar.addAction(QAction("Bookmark", self, triggered=self.add_bookmark))
        self.toolbar.addAction(QAction("Show Bookmarks", self, triggered=self.show_bookmarks))
        self.toolbar.addAction(QAction("Show History", self, triggered=self.show_history))
        self.toolbar.addAction(QAction("Back", self, triggered=self.go_back))
        self.toolbar.addAction(QAction("Forward", self, triggered=self.go_forward))
        self.toolbar.addAction(QAction("Reload", self, triggered=self.reload_page))
        self.toolbar.addAction(QAction("Stop", self, triggered=self.stop_page))
        self.toolbar.addAction(QAction("Zoom +", self, triggered=self.zoom_in))
        self.toolbar.addAction(QAction("Zoom -", self, triggered=self.zoom_out))

        self._running_workers = []
        self.new_tab(self.DEFAULT_HOME)

        if not USE_WEBENGINE:
            QMessageBox.information(self, "PyQtWebEngine missing",
                                    "PyQtWebEngine is not installed. The app will open links in your "
                                    "system browser. To enable in-app browsing install:\n\n"
                                    "pip install PyQtWebEngine\n\n"
                                    "For programmatic DuckDuckGo results install ddgs:\n\n"
                                    "pip install ddgs")

    def _create_tab_with_view(self, view, label="Tab"):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(view)
        idx = self.tabs.addTab(container, label)
        self.tabs.setCurrentIndex(idx)

        # wire title changes (if view supports)
        if USE_WEBENGINE and isinstance(view, QWebEngineView):
            def title_changed(t):
                self.tabs.setTabText(idx, t if t else "Tab")
            view.titleChanged.connect(title_changed)

            def url_changed(qurl):
                if self.tabs.currentIndex() == idx:
                    self.url_input.setText(qurl.toString())
            view.urlChanged.connect(url_changed)

        return container

    def current_view(self):
        container = self.tabs.currentWidget()
        if not container:
            return None
        layout = container.layout()
        if not layout:
            return None
        item = layout.itemAt(0)
        if not item:
            return None
        w = item.widget()
        return w

    def _on_tab_changed(self, index):
        view = self.current_view()
        if USE_WEBENGINE and isinstance(view, QWebEngineView):
            self.url_input.setText(view.url().toString())
        else:
            self.url_input.clear()

    def new_tab(self, url=None):
        url = url or self.DEFAULT_HOME
        view = BrowserTab()
        container = self._create_tab_with_view(view, "Tab")
        if USE_WEBENGINE and isinstance(view, QWebEngineView):
            view.load(QUrl(url))
        return container

    def private_tab(self):
        view = BrowserTab(private=True)
        container = self._create_tab_with_view(view, "Private")
        if USE_WEBENGINE and isinstance(view, QWebEngineView):
            view.load(QUrl(self.DEFAULT_HOME))
        return container

    def close_tab(self, index):
        widget = self.tabs.widget(index)
        if widget:
            self.tabs.removeTab(index)
            widget.deleteLater()

    def _normalize_url(self, text):
        t = text.strip()
        if not t:
            return ""
        if " " in t or "." not in t:
            return ""
        if not t.startswith(("http://", "https://")):
            t = "http://" + t
        return t

    def go_to_url(self):
        text = self.url_input.text().strip()
        if not text:
            return
        normalized = self._normalize_url(text)
        # If looks like a URL, open in-app if available, otherwise system browser
        if normalized:
            view = self.current_view()
            if USE_WEBENGINE and isinstance(view, QWebEngineView):
                view.load(QUrl(normalized))
            else:
                webbrowser.open(normalized)
        else:
            # treat as search
            self.search_input.setText(text)
            self.search_ddgs()

    def search_ddgs(self):
        query = self.search_input.text().strip()
        if not query:
            return

        # If we have webengine and ddgs available, run worker to render results in a new tab
        if USE_WEBENGINE:
            view = BrowserTab()
            container = self._create_tab_with_view(view, f"Searching: {query}")
            view.setHtml("<html><body><h3>Searching... please wait.</h3></body></html>")

            worker = SearchWorker(query, max_results=10)
            self._running_workers.append(worker)

            def on_html_ready(html, title):
                view.setHtml(html)
                idx = self.tabs.indexOf(container)
                if idx != -1:
                    self.tabs.setTabText(idx, title)
                try:
                    self._running_workers.remove(worker)
                except Exception:
                    pass
                worker.deleteLater()

            def on_error(msg):
                # fallback to web search
                url = "https://duckduckgo.com/?q=" + urllib.parse.quote(query)
                view.load(QUrl(url))
                try:
                    self._running_workers.remove(worker)
                except Exception:
                    pass
                worker.deleteLater()
                QMessageBox.information(self, "Search fallback",
                                        "Could not use ddgs library; opened DuckDuckGo web search instead.\n\n"
                                        "To enable in-app programmatic search install:\n\npip install ddgs")

            worker.html_ready.connect(on_html_ready)
            worker.error.connect(on_error)
            worker.start()
        else:
            # fallback: open DuckDuckGo web search in the system browser
            url = "https://duckduckgo.com/?q=" + urllib.parse.quote(query)
            webbrowser.open(url)

    def add_bookmark(self):
        view = self.current_view()
        url = ""
        title = ""
        if USE_WEBENGINE and isinstance(view, QWebEngineView):
            url = view.url().toString()
            title = view.title() or url
        else:
            # No in-app page; use the URL typed by user if any
            url = self.url_input.text().strip()
            title = url
        if not url:
            QMessageBox.information(self, "Bookmark", "No URL to bookmark.")
            return
        bookmarks = load_json(BOOKMARKS_FILE)
        if not any(b.get("url") == url for b in bookmarks):
            bookmarks.append({"url": url, "title": title})
            save_json(BOOKMARKS_FILE, bookmarks)
        QMessageBox.information(self, "Bookmark", f"Bookmarked: {title}")

    def _open_html_in_new_tab(self, html, title="Page"):
        if USE_WEBENGINE:
            view = BrowserTab()
            container = self._create_tab_with_view(view, title)
            view.setHtml(html)
        else:
            # save to temp and open in system browser
            path = os.path.join(DATA_DIR, "temp_page.html")
            with open(path, "w", encoding="utf-8") as f:
                f.write(html)
            webbrowser.open("file://" + os.path.abspath(path))

    def show_bookmarks(self):
        bookmarks = load_json(BOOKMARKS_FILE)
        parts = ["<html><body><h1>Bookmarks</h1><ul>"]
        for b in bookmarks:
            t = b.get("title", b.get("url", "No title"))
            u = b.get("url", "#")
            parts.append(f"<li><a href='{u}'>{t}</a> — <small>{u}</small></li>")
        parts.append("</ul></body></html>")
        html = "\n".join(parts)
        self._open_html_in_new_tab(html, "Bookmarks")

    def show_history(self):
        history = load_json(HISTORY_FILE)
        parts = ["<html><body><h1>History</h1><ul>"]
        for entry in reversed(history[-500:]):
            t = entry.get("title", entry.get("url", ""))
            u = entry.get("url", "#")
            ts = entry.get("timestamp", "")
            parts.append(f"<li><time>{ts}</time> — <a href='{u}'>{t}</a> — <small>{u}</small></li>")
        parts.append("</ul></body></html>")
        html = "\n".join(parts)
        self._open_html_in_new_tab(html, "History")

    def go_back(self):
        view = self.current_view()
        if USE_WEBENGINE and isinstance(view, QWebEngineView):
            view.back()

    def go_forward(self):
        view = self.current_view()
        if USE_WEBENGINE and isinstance(view, QWebEngineView):
            view.forward()

    def reload_page(self):
        view = self.current_view()
        if USE_WEBENGINE and isinstance(view, QWebEngineView):
            view.reload()

    def stop_page(self):
        view = self.current_view()
        if USE_WEBENGINE and isinstance(view, QWebEngineView):
            view.stop()

    def zoom_in(self):
        view = self.current_view()
        if USE_WEBENGINE and isinstance(view, QWebEngineView):
            view.setZoomFactor(view.zoomFactor() + 0.1)

    def zoom_out(self):
        view = self.current_view()
        if USE_WEBENGINE and isinstance(view, QWebEngineView):
            view.setZoomFactor(max(0.25, view.zoomFactor() - 0.1))


def main():
    app = QApplication(sys.argv)
    win = PyqtBrowser()
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()