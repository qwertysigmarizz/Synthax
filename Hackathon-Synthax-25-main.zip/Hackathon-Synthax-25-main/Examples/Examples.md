#Examples

***These are small refrence codes like refrence books, which we can use.***

***Index***

*Examples/Python-JS-WebDev*                                                                                                                                           
A way to connect Python Backends to JS which automatically comes to frontend.
Needed: Python, Flask

***                                                                                                                                            ***
