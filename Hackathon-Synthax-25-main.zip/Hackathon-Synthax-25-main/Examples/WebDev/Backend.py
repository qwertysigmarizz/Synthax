from flask import Flask, jsonify, request, abort
from flask_cors import CORS
import json
import time
from pathlib import Path

DATA_DIR= Path('data')
DATA_DIR.mkdir(exist_ok=True)

FILES = {
    "projects": DATA_DIR/ "projects.json",
    "sessions": DATA_DIR/ "sessions.json",
    "schedules":DATA_DIR/ "schedules.json",
    "alarms": DATA_DIR/ "alarms.json",
}

# Ensure files exist
for f in FILES.values():
    if not f.exists():
        f.write_text("[]")


def read_store(name):
    with open(FILES[name], 'r', encoding='utf-8') as fh:
        return json.load(fh)


def write_store(name, data):
    with open(FILES[name], 'w', encoding='utf-8') as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)


def gen_id():
    # millisecond timestamp id
    return int(time.time() * 1000)


app = Flask(__name__)
CORS(app)


# --- Projects ---
@app.route('/api/projects', methods=['GET'])
def list_projects():
    return jsonify(read_store('projects'))


@app.route('/api/projects', methods=['POST'])
def create_project():
    payload = request.get_json() or {}
    name = payload.get('name', '').strip()
    if not name:
        abort(400, 'name required')
    project = {
        "id": payload.get('id') or f"{name.lower().replace(' ', '_')}_{gen_id()}",
        "name": name,
        "totalTime": float(payload.get('totalTime') or 0.0)
    }
    data = read_store('projects')
    data.append(project)
    write_store('projects', data)
    return jsonify(project), 201


@app.route('/api/projects/<project_id>', methods=['DELETE'])
def delete_project(project_id):
    data = read_store('projects')
    new = [p for p in data if p['id'] != project_id]
    if len(new) == len(data):
        abort(404)
    write_store('projects', new)

    # also remove references in sessions and schedules
    sessions = [s for s in read_store('sessions') if s.get('projectId') != project_id]
    write_store('sessions', sessions)
    schedules = [s for s in read_store('schedules') if s.get('projectId') != project_id]
    write_store('schedules', schedules)
    return '', 204


# --- Sessions ---
@app.route('/api/sessions', methods=['GET'])
def list_sessions():
    return jsonify(read_store('sessions'))


@app.route('/api/sessions', methods=['POST'])
def create_session():
    payload = request.get_json() or {}
    required = ['projectId', 'task', 'duration', 'date']
    for r in required:
        if r not in payload:
            abort(400, f'{r} required')
    session = {
        "id": payload.get('id') or gen_id(),
        "projectId": payload['projectId'],
        "task": payload['task'],
        "duration": payload['duration'],  # seconds
        "date": payload['date']
    }
    data = read_store('sessions')
    data.append(session)
    write_store('sessions', data)

    # update project's totalTime
    projects = read_store('projects')
    for p in projects:
        if p['id'] == session['projectId']:
            p['totalTime'] = float(p.get('totalTime', 0) + session['duration'] / 3600.0)
    write_store('projects', projects)

    return jsonify(session), 201


# --- Schedules (calendar events) ---
@app.route('/api/schedules', methods=['GET'])
def list_schedules():
    return jsonify(read_store('schedules'))


@app.route('/api/schedules', methods=['POST'])
def create_schedule():
    payload = request.get_json() or {}
    required = ['title', 'datetimeISO']
    for r in required:
        if r not in payload:
            abort(400, f'{r} required')
    schedule = {
        "id": payload.get('id') or gen_id(),
        "projectId": payload.get('projectId'),
        "title": payload['title'],
        "datetimeISO": payload['datetimeISO']
    }
    data = read_store('schedules')
    data.append(schedule)
    write_store('schedules', data)
    return jsonify(schedule), 201


@app.route('/api/schedules/<int:sid>', methods=['DELETE'])
def delete_schedule(sid):
    data = read_store('schedules')
    new = [s for s in data if s['id'] != sid]
    if len(new) == len(data):
        abort(404)
    write_store('schedules', new)
    return '', 204


# --- Alarms ---
@app.route('/api/alarms', methods=['GET'])
def list_alarms():
    return jsonify(read_store('alarms'))


@app.route('/api/alarms', methods=['POST'])
def create_alarm():
    payload = request.get_json() or {}
    required = ['title', 'datetimeISO']
    for r in required:
        if r not in payload:
            abort(400, f'{r} required')
    alarm = {
        "id": payload.get('id') or gen_id(),
        "title": payload['title'],
        "datetimeISO": payload['datetimeISO'],
        "triggered": bool(payload.get('triggered', False))
    }
    alarms = read_store('alarms')
    alarms.append(alarm)
    write_store('alarms', alarms)
    return jsonify(alarm), 201


@app.route('/api/alarms/<int:aid>', methods=['DELETE'])
def delete_alarm(aid):
    data = read_store('alarms')
    new = [a for a in data if a['id'] != aid]
    if len(new) == len(data):
        abort(404)
    write_store('alarms', new)
    return '', 204


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)